/**
 * Created by Chelsea on 2024-07-22
 */
public class Main {
  public static void main(String[] args) {
    TelevisionSet televisionSet = new TelevisionSet();
    televisionSet.turnOn();
    televisionSet.increaseVolume();
    televisionSet.changeChannel(5);
    televisionSet.turnOff();
  }
}