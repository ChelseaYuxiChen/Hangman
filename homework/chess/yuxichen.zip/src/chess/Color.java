package chess;

/**
 * Created by Chelsea on 2024-06-10.
 */
public enum Color {
  BLACK, WHITE
}
